import 'package:get/get.dart';

class ProfileController extends GetxController {
  var userName = 'Mark'.obs;
  var userPhoto = 'https://via.placeholder.com/150'.obs; // Placeholder untuk foto profil
}